package utils.enums;

public enum Language 
{
	FRENCH,
	ITALIAN,
	SPANISH,
	PORTUGUESE;
}
