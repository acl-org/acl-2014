package utils.enums;

public enum Metric 
{
	EDIT,
	LCSR,
	XDICE;
}
