hell-coha.csv : instances of the hell-construction in the COHA
hell.coca5000.5w.csv : original co-occurrence frequency list (sparse format)
hell.coca5000.5w.weighted.* : weighted co-occurrence matrix (in DISSECT-readable format)
hell.coca5000.5w.dist.csv : distance matrix
